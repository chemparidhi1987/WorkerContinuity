import logging
class UnknownException(Exception): pass
import argparse
# from ContinuityOfWork import read_input_file,data_preparation,calculate_continuity,write_final_file
import ContinuityOfWork

logging.basicConfig()
logger = logging.getLogger()
logger.handlers = []
handler = logging.StreamHandler()
logger.setLevel(logging.INFO)  
formatter = logging.Formatter("%(asctime)s: %(levelname)s - %(message)s") 
# formatter = logging.Formatter("%(levelname)s - %(message)s") 
handler.setFormatter(formatter)
logger.addHandler(handler) 
    

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file_name", help="Path of the input file (Worker Data file)", required=True)
    parser.add_argument("--target_file_name", help="Path of the output file (Worker Continutiy Result", required=True)
    # args = parser.parse_args()
    args, unknown = parser.parse_known_args()
    
    worker_file,final_file = '',''
    if args.input_file_name:
        worker_file = args.input_file_name
    if args.target_file_name:
        final_file = args.target_file_name

    logger.info ('Continuity Of Work Python Program Starts Here')
    
    #Reading the Input CSV File into DataFrame
    logger.info ('Read CSV File into DataFrame {}' .format(worker_file))
    WorkerRawDF = ContinuityOfWork.read_input_file(worker_file)
    
    # Prepare Data with required columns for calulating Worker's Continuity
    logger.info ('Derive Columsn for Calulations')
    FilteredDF = ContinuityOfWork.data_preparation(WorkerRawDF)
    
    # Calculate continuity based on the derived values
    logger.info ('Calculate Worker\'s Continuity ')
    FinalDF = ContinuityOfWork.calculate_continuity(FilteredDF)

    # Write the DataFrame into CSV File System
    logger.info ('Write the resultant Dataframe into CSV File {}' .format(final_file))
    ContinuityOfWork.write_final_file(FinalDF,final_file)
    
    logger.info ('End of Python Program')


                               
