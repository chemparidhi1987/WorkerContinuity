import os
import logging
class UnknownException(Exception): pass
import io
import pandas as pd
import numpy as np

logging.basicConfig()
logger = logging.getLogger()
logger.handlers = []
handler = logging.StreamHandler()
logger.setLevel(logging.INFO)  
formatter = logging.Formatter("%(asctime)s: %(levelname)s - %(message)s") 
# formatter = logging.Formatter("%(levelname)s - %(message)s") 
handler.setFormatter(formatter)
logger.addHandler(handler) 
    

def read_input_file(worker_file):
    
    try:
        WorkerRawDF = pd.read_csv(worker_file \
                                 ,sep=',' \
                                 ,engine='python' \
                                 ,dtype={'Worker': np.int64
                                        ,'Employer': np.int64
                                        ,'Role': np.int64
                                        ,'Date': np.datetime64
                                        })
    except FileNotFoundError:
        logger.error ("File not found {}" .format(worker_file))
        raise Exception ("File not found {}" .format(worker_file))
    except pd.errors.EmptyDataError:
        logger.error ("No data in File {}" .format(worker_file))
        raise Exception ("No data in File {}" .format(worker_file))
    except Exception:
        logger.error ("Error while Reading file {} into Pandas Data Frame" .format(worker_file))
        raise Exception ("Error while Reading file {} into Pandas Data Frame" .format(worker_file))
    
    return WorkerRawDF

def data_preparation(WorkerRawDF):
    
    try:
        WorkerRawDF['Date'] = pd.to_datetime(WorkerRawDF['Date']).dt.normalize()
        WorkerSortedDF = WorkerRawDF.sort_values(by=['Worker','Date'], axis=0, ascending=True, inplace=False, ignore_index=False)
        WorkerSortedDF['diff'] = WorkerSortedDF.groupby(by=['Worker', 'Employer','Role'])['Date'].diff() / np.timedelta64(1, 'D')
        WorkerSortedDF['diff'] = WorkerSortedDF['diff'].fillna(1)
        FilteredDF = WorkerSortedDF[WorkerSortedDF['diff'] <= 6.0]
        
    except BaseException as e:
        logger.error ('Error Occured in data_preparation Para')
        raise Exception ('The exception: {}'.format(e))
    
    return FilteredDF

def calculate_continuity(FilteredDF):
    try:
        ContinuityDF = FilteredDF.groupby(['Worker', 'Employer','Role']).size().reset_index(name='Count') 
        FinalDF1 = ContinuityDF.groupby(['Worker'], sort=True)['Count'].max().reset_index(name='Continuity')
        FinalDF = FinalDF1.sort_values(by=['Continuity'], axis=0, ascending=False, inplace=False, ignore_index=False)
        
    except BaseException as e:
        logger.error ('Error Occured in calculate_continuity Para')
        raise Exception ('The exception: {}'.format(e))
    
    return FinalDF

def write_final_file(FinalDF,final_file):
    
    try:
        FinalDF.to_csv(final_file, index=False, header=True, sep=',')
    except BaseException as e:
        logger.error ('Error Occured in write_final_file Para')
        raise Exception ('The exception: {}'.format(e))
        
    return 0

