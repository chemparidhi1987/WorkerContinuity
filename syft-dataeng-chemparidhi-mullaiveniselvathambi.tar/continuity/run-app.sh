#!/usr/bin/ksh
#
################################################################################################
# SCRIPT NAME 	  : run-app.sh
#
# DESCRIPTION     : THIS SCRIPT WILL SUBMIT THE PYTHON MODULE main.py TO CALCULATE THE WORKERS
#                   CONTINUITY BASED ON EMPLOYER AND ROLE 
#
# AUTHOR		  : CHEMPARIDHI M S 
#
# INITIAL VERSION : 23-MAY-2021
#
# VERSION HISTORY : DATE         | NAME                        | VERSION NO     
#                                           	
###############################################################################################
#sh run-app.sh > run-app_sh.log 2&1

function log_message {
Year=`date +%Y`
Month=`date +%m`
Day=`date +%d`
Hour=`date +%H`
Minute=`date +%M`
Second=`date +%S`
    echo "$Day-$Month-$Year $Hour:$Minute:$Second [INFO] : $1"
}

function error_message {
Year=`date +%Y`
Month=`date +%m`
Day=`date +%d`
Hour=`date +%H`
Minute=`date +%M`
Second=`date +%S`
    echo "$Day-$Month-$Year $Hour:$Minute:$Second [ERROR]: $1"
}


#############################################################( SCRIPT STARTS HERE )##########################################################
script_name=$0
base_path=`pwd`
python_path=${base_path}'/IndeedFlex'
python_script=${python_path}'/main.py'
input_file=${base_path}'/worker_activity.csv'
target_file=${base_path}'/results.csv'
log_message "JOB SUBMIT STARTS HERE FOR " ${script_name} 

log_message "python3 ${python_script} --input_file_name ${input_file} --target_file_name ${target_file} "
python3 ${python_script} --input_file_name ${input_file} --target_file_name ${target_file} 
RC0=$?
if [ $RC0 -eq 0 ]; then
	log_message "JOB COMPLETED"
else
	log_message "python ${base_path}/${python_script} --input_file_name ${input_file} --target_file_name ${target_file}"
	error_message "FAILED AT STEP EXECUTING PYTHON, CHECK THE LOGS"
	exit 1
fi

exit 0

